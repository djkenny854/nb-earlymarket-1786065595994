// ══════════════════════════════════════════════
//  DARK MODE
// ══════════════════════════════════════════════
if (localStorage.getItem("afri_theme") === "dark") document.body.classList.add("dark");

// ══════════════════════════════════════════════
//  AUTH CHECK
// ══════════════════════════════════════════════
const token = localStorage.getItem("token");
if (!token) window.location.href = "/login.html";

const API_BASE = "https://afrisocial-backend.onrender.com";
const grid = document.getElementById("vybzeGrid");

// ══════════════════════════════════════════════
//  SANITIZER
// ══════════════════════════════════════════════
function sanitize(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

// Open search
document.getElementById("openSearch").onclick = () => {
  location.href = "search.html";
};

// ══════════════════════════════════════════════
//  FORMAT VIEW COUNT (e.g. 1234 → 1.2K, 1234567 → 1.2M)
// ══════════════════════════════════════════════
function formatCount(n) {
  n = Number(n) || 0;
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1).replace(/\.0$/, '') + 'M';
  if (n >= 1_000)     return (n / 1_000).toFixed(n >= 10_000 ? 0 : 1).replace(/\.0$/, '') + 'K';
  return String(n);
}

// ══════════════════════════════════════════════
//  SKELETON LOADER
// ══════════════════════════════════════════════
function showSkeletons(count = 6) {
  grid.innerHTML = "";
  for (let i = 0; i < count; i++) {
    grid.innerHTML += `
      <div class="vybze-cell">
        <div class="skeleton-card"></div>
        <div class="skeleton-userline"></div>
      </div>
    `;
  }
}

// ══════════════════════════════════════════════
//  LOAD VYBZE FEED
// ══════════════════════════════════════════════
async function loadVybze() {
  showSkeletons(6);

  try {
    const res  = await fetch(`${API_BASE}/api/vybze/feed`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    const videos = data.videos || [];

    grid.innerHTML = "";

    if (videos.length === 0) {
      grid.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;
          padding:48px 16px;color:#9CA3AF;font-size:14px;">
          No vybze yet. Check back later!
        </div>
      `;
      return;
    }

    videos.forEach(video => {
      const cell = document.createElement("div");
      cell.className = "vybze-cell";

      const username = sanitize(video.user.username || '');
      const avatar   = video.user.profilePicture || '/uploads/images/africa.png';
      const verified = video.user.isVerified
        ? `<svg class="verified" viewBox="0 0 24 24" aria-hidden="true"><path d="M22.5 12.5c0-1.58-.875-2.95-2.148-3.6.154-.435.238-.905.238-1.4 0-2.21-1.71-3.998-3.818-3.998-.47 0-.92.084-1.336.25C14.818 2.415 13.51 1.5 12 1.5s-2.816.917-3.437 2.25c-.415-.165-.866-.25-1.336-.25-2.11 0-3.818 1.79-3.818 4 0 .494.083.964.237 1.4-1.272.65-2.146 2.018-2.146 3.6 0 1.495.782 2.798 1.942 3.486-.02.17-.032.34-.032.514 0 2.21 1.708 4 3.818 4 .47 0 .92-.086 1.336-.25.62 1.334 1.926 2.25 3.437 2.25 1.512 0 2.818-.916 3.437-2.25.415.163.865.248 1.336.248 2.11 0 3.818-1.79 3.818-4 0-.174-.012-.344-.033-.513 1.158-.687 1.943-1.99 1.943-3.484zm-6.616-3.334l-4.334 6.5c-.145.217-.382.354-.642.367h-.046c-.245 0-.48-.094-.658-.272l-2.667-2.677c-.36-.36-.357-.943.005-1.302.357-.36.94-.36 1.3.005l1.872 1.882 3.682-5.527c.282-.42.85-.535 1.272-.255.418.282.532.85.25 1.272z"/></svg>`
        : '';

      cell.innerHTML = `
        <div class="vybze-card">
          <video
            class="vybze-video"
            src="${video.video}"
            muted
            playsinline
            loop
            preload="metadata"
          ></video>
          <div class="vybze-views" aria-label="views">
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 5C7 5 2.73 8.11 1 12.5 2.73 16.89 7 20 12 20s9.27-3.11 11-7.5C21.27 8.11 17 5 12 5zm0 12.5a5 5 0 110-10 5 5 0 010 10zm0-8a3 3 0 100 6 3 3 0 000-6z"/>
            </svg>
            <span>${formatCount(video.views || 0)}</span>
          </div>
          <button class="vybze-report-btn"
            title="Report this video"
            data-video-id="${video._id}">
            <svg viewBox="0 0 24 24" width="14" height="14"
              fill="none" stroke="white" stroke-width="2"
              stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/>
              <line x1="4" y1="22" x2="4" y2="15"/>
            </svg>
          </button>
        </div>
        <div class="vybze-user-row">
          <img src="${avatar}" alt="">
          <span class="uname">${username}</span>
          ${verified}
        </div>
      `;

      const card = cell.querySelector('.vybze-card');
      card.addEventListener("click", (e) => {
        if (e.target.closest(".vybze-report-btn")) return;
        window.location.href = `vybze-player.html?videoId=${video._id}`;
      });

      cell.querySelector(".vybze-report-btn")
        .addEventListener("click", (e) => {
          e.stopPropagation();
          showReportModal(video._id, 'video');
        });

      grid.appendChild(cell);
    });

    // Auto play on scroll
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          const vid = entry.target;
          if (entry.isIntersecting) {
            vid.play().catch(() => {});
          } else {
            vid.pause();
          }
        });
      },
      { threshold: 0.7 }
    );

    document.querySelectorAll(".vybze-video").forEach(vid => observer.observe(vid));

  } catch (err) {
    console.error("Failed to load vybze:", err);
    grid.innerHTML = `
      <div style="grid-column:1/-1;text-align:center;
        padding:48px 16px;color:#9CA3AF;font-size:14px;">
        Couldn't load vybze. Try again later.
      </div>
    `;
  }
}

loadVybze();

// ══════════════════════════════════════════════
//  NOTIFICATION BADGE
// ══════════════════════════════════════════════
const notificationBtn   = document.getElementById("notificationBtn");
const notificationBadge = document.getElementById("notificationBadge");

async function loadNotificationBadge() {
  if (!token) return;
  try {
    const res  = await fetch(
      `${API_BASE}/api/notifications/unread-count`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const data = await res.json();
    const count = data.count || 0;
    if (count > 0) {
      notificationBadge.textContent = count > 99 ? '99+' : count;
      notificationBadge.classList.add("show");
    } else {
      notificationBadge.textContent = '';
      notificationBadge.classList.remove("show");
    }
  } catch (err) { console.error(err); }
}

notificationBtn.addEventListener("click", () => {
  window.location.href = "/notification.html";
});

loadNotificationBadge();

// ══════════════════════════════════════════════
//  MESSAGE BADGE — dynamic, never stagnant
// ══════════════════════════════════════════════
const messageBadge = document.getElementById("messageBadge");

async function loadUnreadMessages() {
  if (!token) return;
  try {
    const res  = await fetch(
      `${API_BASE}/api/messages/unread-count`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const data = await res.json();
    const count = data.count || 0;

    if (count > 0) {
      messageBadge.textContent = count > 99 ? "99+" : count;
      messageBadge.classList.add("visible");
    } else {
      messageBadge.textContent = "";
      messageBadge.classList.remove("visible");
    }
  } catch (err) {
    // Hide on error — never show stale data
    messageBadge.classList.remove("visible");
    console.error(err);
  }
}

document.getElementById("chatNavItem")
  .addEventListener("click", e => {
    e.preventDefault();
    window.location.href = "/message.html";
  });

loadUnreadMessages();

// Refresh every 30 seconds while page is open
setInterval(loadUnreadMessages, 30_000);

// ══════════════════════════════════════════════
//  REPORT MODAL
// ══════════════════════════════════════════════
function showReportModal(contentId, contentType) {
  const reasons = [
    { value: 'spam',           label: '🚫 Spam' },
    { value: 'hate_speech',    label: '😡 Hate Speech' },
    { value: 'explicit',       label: '🔞 Explicit Content' },
    { value: 'malicious_link', label: '🔗 Malicious Link' },
    { value: 'other',          label: '⚠️ Other' },
  ];

  const modal = document.createElement('div');
  modal.style.cssText = `
    position:fixed;inset:0;background:rgba(0,0,0,0.5);
    display:flex;align-items:flex-end;justify-content:center;
    z-index:9999;padding:20px;
  `;

  const sheet = document.createElement('div');
  sheet.style.cssText = `
    background:white;border-radius:20px;padding:24px;
    width:100%;max-width:500px;
  `;

  sheet.innerHTML = `
    <h3 style="font-size:18px;font-weight:700;
      margin-bottom:16px;color:#111827;">
      Report Video
    </h3>
    <p style="font-size:14px;color:#6B7280;margin-bottom:20px;">
      Why are you reporting this?
    </p>
    ${reasons.map(r => `
      <button data-reason="${r.value}"
        style="display:block;width:100%;text-align:left;
        padding:14px 16px;border:1.5px solid #E5E7EB;
        border-radius:12px;background:white;font-size:15px;
        font-weight:500;color:#111827;margin-bottom:8px;
        cursor:pointer;">
        ${r.label}
      </button>
    `).join('')}
    <button id="cancelReportBtn"
      style="display:block;width:100%;padding:14px;border:none;
      background:#F3F4F6;border-radius:12px;font-size:15px;
      font-weight:600;color:#6B7280;margin-top:4px;cursor:pointer;">
      Cancel
    </button>
  `;

  modal.appendChild(sheet);
  document.body.appendChild(modal);

  sheet.querySelectorAll('[data-reason]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const reason = btn.dataset.reason;
      try {
        await fetch(`${API_BASE}/api/moderation/report`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({ contentId, contentType, reason })
        });
      } catch (err) { console.error('Report error:', err); }

      document.body.removeChild(modal);

      const toast = document.createElement('div');
      toast.style.cssText = `
        position:fixed;bottom:80px;left:50%;
        transform:translateX(-50%);background:#000A23;
        color:white;padding:12px 24px;border-radius:100px;
        font-size:14px;font-weight:500;z-index:9999;
      `;
      toast.textContent = '✅ Reported. Thank you!';
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 3000);
    });
  });

  sheet.querySelector('#cancelReportBtn')
    .addEventListener('click', () => {
      document.body.removeChild(modal);
    });
}
