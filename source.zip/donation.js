const options = document.querySelectorAll(".star-option");
const customInput = document.querySelector("#customStars");
const total = document.querySelector("#totalStars");
const donateBtn = document.querySelector("#donateBtn");
const successModal = document.querySelector("#successModal");
const closeSuccessModalBtn = document.querySelector("#closeModal");
const balanceEl = document.querySelector(".balance");
const goalRaisedEl = document.querySelector("#goalRaised");
const progressFillEl = document.querySelector(".progress-fill");
const messageInput = document.querySelector("#message");
const buyMoreBtn = document.querySelector(".balance-card button");

const token = localStorage.getItem("token");
if (!token) {
    window.location.href = "/login.html";
}

const baseUrl = "https://afrisocial-backend.onrender.com";
const state = {
    selectedStars: 100,
    balance: 0,
    donatedTotal: 0,
    hasPin: false,
    pendingAction: null
};

function applyTheme() {
    if (localStorage.getItem("afri_theme") === "dark") {
        document.body.classList.add("dark-mode");
    }
}

function ensureToast() {
    let toast = document.getElementById("donationToast");
    if (toast) return toast;

    toast = document.createElement("div");
    toast.id = "donationToast";
    toast.style.cssText = "position:fixed;right:16px;bottom:16px;max-width:320px;padding:12px 14px;border-radius:999px;background:#111827;color:#fff;box-shadow:0 12px 28px rgba(0,0,0,.2);z-index:9999;opacity:0;transform:translateY(8px);transition:all .25s ease;";
    document.body.appendChild(toast);
    return toast;
}

function showToast(msg, isError = false) {
    const toast = ensureToast();
    toast.textContent = msg;
    toast.style.background = isError ? "#EF4444" : "#111827";
    toast.style.opacity = "1";
    toast.style.transform = "translateY(0)";

    clearTimeout(showToast.timeout);
    showToast.timeout = setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(8px)";
    }, 2800);
}

function createPinModal() {
    let pinModal = document.getElementById("donationPinModal");
    if (pinModal) return pinModal;

    pinModal = document.createElement("div");
    pinModal.id = "donationPinModal";
    pinModal.className = "modal";
    pinModal.innerHTML = `
        <div class="modal-content" style="max-width:420px;">
            <h2>Confirm Donation</h2>
            <p id="pinLabel" style="margin:8px 0 18px; color:#6b7280;">Enter your wallet PIN to continue</p>
            <div style="display:flex;justify-content:center;gap:10px;margin-bottom:18px;">
                <input class="pin-box" type="password" inputmode="numeric" maxlength="1" style="width:46px;height:52px;border:1px solid #e5e7eb;border-radius:12px;text-align:center;font-size:1.2rem;" />
                <input class="pin-box" type="password" inputmode="numeric" maxlength="1" style="width:46px;height:52px;border:1px solid #e5e7eb;border-radius:12px;text-align:center;font-size:1.2rem;" />
                <input class="pin-box" type="password" inputmode="numeric" maxlength="1" style="width:46px;height:52px;border:1px solid #e5e7eb;border-radius:12px;text-align:center;font-size:1.2rem;" />
                <input class="pin-box" type="password" inputmode="numeric" maxlength="1" style="width:46px;height:52px;border:1px solid #e5e7eb;border-radius:12px;text-align:center;font-size:1.2rem;" />
            </div>
            <div style="display:flex;justify-content:center;gap:10px;">
                <button type="button" id="cancelPinBtn" style="background:#e5e7eb;color:#111827;box-shadow:none;">Cancel</button>
                <button type="button" id="confirmPinBtn">Continue</button>
            </div>
        </div>
    `;

    pinModal.addEventListener("click", (e) => {
        if (e.target === pinModal) {
            pinModal.style.display = "none";
            state.pendingAction = null;
        }
    });

    document.body.appendChild(pinModal);

    const boxes = Array.from(pinModal.querySelectorAll(".pin-box"));
    boxes.forEach((box, index) => {
        box.addEventListener("input", () => {
            box.value = box.value.replace(/\D/g, "").slice(0, 1);
            if (box.value && index < boxes.length - 1) {
                boxes[index + 1].focus();
            }
        });

        box.addEventListener("keydown", (e) => {
            if (e.key === "Backspace" && !box.value && index > 0) {
                boxes[index - 1].focus();
            }
        });
    });

    pinModal.querySelector("#cancelPinBtn").addEventListener("click", () => {
        pinModal.style.display = "none";
        state.pendingAction = null;
    });

    pinModal.querySelector("#confirmPinBtn").addEventListener("click", () => {
        const pin = boxes.map((b) => b.value).join("");
        if (pin.length < 4) {
            showToast("Enter your 4-digit PIN", true);
            return;
        }

        pinModal.style.display = "none";
        if (typeof state.pendingAction === "function") {
            state.pendingAction(pin);
        }
    });

    return pinModal;
}

function openPinModal(label, onConfirm) {
    const pinModal = createPinModal();
    document.getElementById("pinLabel").textContent = label || "Enter your wallet PIN to continue";
    const boxes = Array.from(pinModal.querySelectorAll(".pin-box"));
    boxes.forEach((box) => {
        box.value = "";
    });
    state.pendingAction = onConfirm;
    pinModal.style.display = "flex";
    setTimeout(() => boxes[0]?.focus(), 120);
}

function updateTotal(value) {
    state.selectedStars = Number(value);

    if (Number.isNaN(state.selectedStars) || state.selectedStars < 0) {
        state.selectedStars = 0;
    }

    total.textContent = `${state.selectedStars.toLocaleString()} ⭐`;
}

function updateBalanceUI() {
    balanceEl.textContent = `⭐ ${state.balance.toLocaleString()} Stars`;
    if (goalRaisedEl) {
        goalRaisedEl.textContent = `⭐ ${state.donatedTotal.toLocaleString()} of ⭐ 1,000,000 Stars raised`;
    }
    if (progressFillEl) {
        const percent = Math.min(100, (state.donatedTotal / 1000000) * 100);
        progressFillEl.style.width = `${percent}%`;
    }
}

async function loadWallet() {
    try {
        const res = await fetch(`${baseUrl}/api/wallet`, {
            headers: { Authorization: `Bearer ${token}` }
        });

        if (!res.ok) {
            throw new Error("Unable to load wallet");
        }

        const data = await res.json();
        state.balance = data.starBalance || data.availableBalance || 0;
        state.hasPin = data.hasPin || false;
        updateBalanceUI();
    } catch (err) {
        console.error("Wallet load error:", err);
        state.balance = 0;
        updateBalanceUI();
    }
}

function resetDonationSelection() {
    options.forEach((card) => card.classList.remove("active"));
    options[0]?.classList.add("active");
    customInput.value = "";
    updateTotal(100);
}

document.getElementById("share-btn").addEventListener("click", async () => {
    const shareData = {
        title: document.title,
        text: "Check the support page out:",
        url: window.location.href
    };
    
    try {
        if (navigator.share) {
            await navigator.share(shareData);
        } else {
            await navigator.clipboard.writeText(shareData.url);
            alert("Link copied to clipboard!");
        }
    } catch (err) {
        console.error("Error sharing:", err);
    }
});

function showSuccessModal() {
    successModal.style.display = "flex";
}

options.forEach((option) => {
    option.addEventListener("click", () => {
        options.forEach((card) => card.classList.remove("active"));
        option.classList.add("active");
        customInput.value = "";
        updateTotal(option.dataset.stars);
    });
});

customInput.addEventListener("input", () => {
    options.forEach((card) => card.classList.remove("active"));
    updateTotal(customInput.value);
});

donateBtn.addEventListener("click", () => {
    if (state.selectedStars <= 0) {
        showToast("Please choose how many Stars you'd like to donate.", true);
        return;
    }

    if (state.selectedStars > state.balance) {
        showToast("Insufficient star balance", true);
        return;
    }

    openPinModal(`Donate ⭐ ${state.selectedStars.toLocaleString()} to Afrisocial`, async (pin) => {
        try {
            let res = await fetch(`${baseUrl}/api/wallet/donate`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    stars: state.selectedStars,
                    message: messageInput.value.trim(),
                    pin
                })
            });

            if (!res.ok && res.status === 404) {
                res = await fetch(`${baseUrl}/api/donate-stars`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        stars: state.selectedStars,
                        message: messageInput.value.trim(),
                        pin
                    })
                });
            }

            let data = null;
            try {
                data = await res.json();
            } catch {}

            if (!res.ok) {
                throw new Error(data?.message || "Donation failed");
            }

            state.balance -= state.selectedStars;
            state.donatedTotal += state.selectedStars;
            updateBalanceUI();
            resetDonationSelection();
            messageInput.value = "";
            showSuccessModal();
            showToast("Donation sent successfully!");
        } catch (err) {
            showToast(err.message || "Donation failed", true);
        }
    });
});

closeSuccessModalBtn.addEventListener("click", () => {
    successModal.style.display = "none";
});

successModal.addEventListener("click", (e) => {
    if (e.target === successModal) {
        successModal.style.display = "none";
    }
});

buyMoreBtn.addEventListener("click", () => {
    window.location.href = "./wallet.html";
});

async function loadDonationStats() {

    try {

        const res = await fetch(
            `${baseUrl}/api/wallet/donation/stats`
        );

        if (!res.ok) {
            throw new Error("Failed to load donation stats");
        }

        const data = await res.json();

        state.donatedTotal = data.totalStars || 0;

        if (goalRaisedEl) {

            goalRaisedEl.textContent =
                `⭐ ${data.totalStars.toLocaleString()} of ⭐ ${data.goal.toLocaleString()} Stars raised`;

        }

        if (progressFillEl) {

            progressFillEl.style.width =
                `${data.percentage}%`;

        }

    } catch (err) {

        console.error("Donation stats error:", err);

    }

}

applyTheme();
loadWallet();
loadDonationStats();
resetDonationSelection();
