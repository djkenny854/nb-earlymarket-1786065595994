// ══════════════════════════════════════════════
//  DARK MODE
// ══════════════════════════════════════════════
if (localStorage.getItem("afri_theme") === "dark") document.body.classList.add("dark");

// ══════════════════════════════════════════════
//  CONFIG
// ══════════════════════════════════════════════
const API_BASE      = "https://afrisocial-backend.onrender.com";
const token         = localStorage.getItem("token");
const currentUserId = localStorage.getItem("userId");

if (!token || !currentUserId) window.location.href = "/login.html";

const params    = new URLSearchParams(window.location.search);
const groupId   = params.get("groupId");
const groupName = params.get("name") || "Group";

if (!groupId) window.location.href = "/message.html";

// ══════════════════════════════════════════════
//  GIFT CATALOGUE
// ══════════════════════════════════════════════
const GIFTS = [
  { emoji:"❤️",  name:"Heart",      stars:10   },
  { emoji:"🌹",  name:"Rose",       stars:15   },
  { emoji:"🍎",  name:"Apple",      stars:20   },
  { emoji:"🍇",  name:"Grapes",     stars:25   },
  { emoji:"🌸",  name:"Blossom",    stars:30   },
  { emoji:"🍓",  name:"Strawberry", stars:40   },
  { emoji:"💐",  name:"Bouquet",    stars:50   },
  { emoji:"🎂",  name:"Cake",       stars:60   },
  { emoji:"🦋",  name:"Butterfly",  stars:75   },
  { emoji:"💎",  name:"Diamond",    stars:90   },
  { emoji:"👑",  name:"Crown",      stars:120  },
  { emoji:"🏆",  name:"Trophy",     stars:150  },
  { emoji:"🚀",  name:"Rocket",     stars:200  },
  { emoji:"🎸",  name:"Guitar",     stars:250  },
  { emoji:"🌍",  name:"Globe",      stars:300  },
  { emoji:"🏎️",  name:"Sports Car", stars:500  },
  { emoji:"🚁",  name:"Helicopter", stars:750  },
  { emoji:"🚢",  name:"Cruise",     stars:1000 },
  { emoji:"🛸",  name:"UFO",        stars:1500 },
  { emoji:"🏰",  name:"Castle",     stars:2000 },
  { emoji:"🚗",  name:"Car",        stars:3000 },
  { emoji:"✈️",  name:"Jet",        stars:5000 },
];

// ══════════════════════════════════════════════
//  STATE
// ══════════════════════════════════════════════
let groupData      = null;
let isAdmin        = false;
let members        = [];
let polling        = null;
let replyingTo     = null;
let selectedMsg    = null;
let giftSelected   = null;
let giftBalance    = 0;
let mediaRecorder  = null;
let voiceChunks    = [];
let voiceInterval  = null;
let voiceSecs      = 0;
let bubbleColor    = localStorage.getItem("bubbleColor") || "#000A23";
let chatBg         = localStorage.getItem(`groupBg_${groupId}`) || "";
let msgPage        = 1;
let hasMore        = true;
let loadingMsgs    = false;
let memberToRemove = null;

// DOM
const msgList      = document.getElementById("messagesList");
const chatMessages = document.getElementById("chatMessages");
const msgInput     = document.getElementById("msgInput");
const sendBtn      = document.getElementById("sendBtn");
const attachOpts   = document.getElementById("attachOptions");
const voiceBar     = document.getElementById("voiceBar");
const inputArea    = document.getElementById("chatInputArea");
const replyBar     = document.getElementById("replyBar");

// ══════════════════════════════════════════════
//  HELPERS
// ══════════════════════════════════════════════
function esc(t) {
  if (!t) return "";
  const d = document.createElement("div");
  d.textContent = t; return d.innerHTML;
}

function fmtTime(date) {
  const d = new Date(date), now = new Date();
  if (d.toDateString() === now.toDateString())
    return d.toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" });
  return d.toLocaleDateString();
}

function fmtDate(date) {
  const d = new Date(date), now = new Date();
  const diff = Math.floor((now - d) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString([], { weekday:"long", month:"short", day:"numeric" });
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg; t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}

function scrollBottom(smooth = false) {
  chatMessages.scrollTo({ top: chatMessages.scrollHeight, behavior: smooth ? "smooth" : "auto" });
}

async function api(ep, opts = {}) {
  const res = await fetch(`${API_BASE}${ep}`, {
    headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json", ...opts.headers },
    ...opts
  });
  if (!res.ok) throw new Error((await res.json()).message || "API error");
  return res.json();
}

// ══════════════════════════════════════════════
//  SKELETON LOADING
// ══════════════════════════════════════════════
function showSkeletons() {
  msgList.innerHTML = "";
  const patterns = ["recv","recv","sent","recv","sent","sent","recv","sent","recv","sent"];
  patterns.forEach(type => {
    const wrap = document.createElement("div");
    wrap.className = `skel-msg-wrap ${type}`;
    wrap.innerHTML = `
      ${type === "recv" ? `<div class="skel skel-msg-avatar"></div>` : ""}
      <div class="skel skel-bubble"></div>
    `;
    msgList.appendChild(wrap);
  });
}

// ══════════════════════════════════════════════
//  LOAD GROUP INFO
// ══════════════════════════════════════════════
async function loadGroupInfo() {
  try {
    const data = await api(`/api/messages/groups/${groupId}`);
    groupData = data.group || data;
    members   = data.members || groupData.members || [];
    isAdmin   = groupData.admin === currentUserId ||
                groupData.admins?.includes(currentUserId) ||
                members.find(m => m._id === currentUserId)?.role === "admin";

    renderHeader(groupData);
  } catch(e) {
    // Fallback
    renderHeaderFallback();
  }
}

function renderHeader(group) {
  const wrap = document.getElementById("chatHeaderUser");
  const initials = (group.name || "G").substring(0,2).toUpperCase();

  wrap.innerHTML = `
    <div class="chat-header-avatar-wrap">
      <div class="group-header-avatar">
        ${group.profilePicture
          ? `<img src="${group.profilePicture}"
               onerror="this.parentElement.textContent='${initials}'" />`
          : initials}
      </div>
    </div>
    <div class="chat-header-details">
      <strong>${esc(group.name || groupName)}</strong>
      <span>${members.length || group.memberCount || 0} members</span>
    </div>
  `;

  wrap.addEventListener("click", openGroupInfo);
}

function renderHeaderFallback() {
  const wrap = document.getElementById("chatHeaderUser");
  const initials = groupName.substring(0,2).toUpperCase();
  wrap.innerHTML = `
    <div class="chat-header-avatar-wrap">
      <div class="group-header-avatar">${initials}</div>
    </div>
    <div class="chat-header-details">
      <strong>${esc(groupName)}</strong>
      <span>Group</span>
    </div>
  `;
  wrap.addEventListener("click", openGroupInfo);
}

// ══════════════════════════════════════════════
//  LOAD MESSAGES
// ══════════════════════════════════════════════
async function loadMessages(reset = true) {
  if (loadingMsgs || (!hasMore && !reset)) return;
  loadingMsgs = true;

  if (reset) showSkeletons();

  try {
    const data = await api(
      `/api/messages/groups/${groupId}/messages?page=${msgPage}&limit=30`
    );
    const msgs = data.messages || [];

    if (reset) { msgList.innerHTML = ""; msgPage = 1; }

    if (msgs.length === 0 && reset) {
      msgList.innerHTML = `
        <div style="text-align:center;padding:48px 20px;color:#9CA3AF;">
          <div style="font-size:48px;margin-bottom:12px;">👥</div>
          <p style="font-size:15px;font-weight:600;">
            No messages yet.<br>Start the conversation!
          </p>
        </div>`;
      loadingMsgs = false; return;
    }

    hasMore = msgs.length === 30;
    const sorted = [...msgs].reverse();

    if (!reset) {
      sorted.forEach(m => appendMsg(m));
    } else {
      msgList.innerHTML = "";
      let lastDate = "";
      sorted.forEach(m => {
        const d = fmtDate(m.createdAt);
        if (d !== lastDate) {
          lastDate = d;
          const div = document.createElement("div");
          div.className = "date-divider";
          div.innerHTML = `<span>${d}</span>`;
          msgList.appendChild(div);
        }
        appendMsg(m);
      });
      scrollBottom();
    }

    loadingMsgs = false;
    if (reset && typeof window.AfriRefreshBadges === "function") window.AfriRefreshBadges();
  } catch(e) {
    console.error(e);
    loadingMsgs = false;
    if (reset) {
      msgList.innerHTML = `
        <div style="text-align:center;padding:40px;color:#EF4444;">
          Failed to load messages.
          <br><button onclick="loadMessages()"
            style="margin-top:10px;padding:8px 16px;background:#000A23;
            color:#fff;border:none;border-radius:8px;cursor:pointer;">
            Retry
          </button>
        </div>`;
    }
  }
}

// ══════════════════════════════════════════════
//  APPEND MESSAGE
// ══════════════════════════════════════════════
function appendMsg(msg, animate = false) {
  const isSent  = msg.sender === currentUserId || msg.sender?._id === currentUserId;
  const sender  = msg.senderDetails || (typeof msg.sender === "object" ? msg.sender : {});

  const row = document.createElement("div");
  row.className = `msg-row ${isSent ? "sent" : "recv"}`;
  row.dataset.msgId = msg._id;
  if (animate) row.style.animation = "fadeIn 0.2s ease";

  let content = "";

  // Reply preview
  if (msg.replyTo) {
    content += `<div class="reply-preview">↩ ${esc(msg.replyTo.text || "Media")}</div>`;
  }

  // Body
  if (msg.type === "gift") {
    content += `
      <div class="msg-gift">
        <div class="gift-badge">🎁 ${esc(msg.giftType||"Gift")} ⭐ ${Number(msg.giftStars||0).toLocaleString()}</div>
        <div class="gift-label">${isSent ? "You" : esc(sender.fullName||sender.username||"Someone")} sent a ${esc(msg.giftType||"gift")} gift 🎁</div>
      </div>
    `;
  } else if (msg.type === "voice" || msg.media?.match(/\.(mp3|wav|ogg|webm)$/i)) {
    const src = msg.media?.startsWith("http") ? msg.media : `${API_BASE}${msg.media}`;
    content += `
      <div class="msg-voice">
        <button class="voice-play" onclick="playVoice('${src}',this)">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
            <polygon points="5 3 19 12 5 21 5 3"/>
          </svg>
        </button>
        <div class="voice-bar-visual"></div>
        <span class="voice-dur">${msg.voiceDuration || "0:00"}</span>
      </div>
    `;
  } else if (msg.media?.match(/\.(jpg|jpeg|png|gif|webp)$/i)) {
    const src = msg.media.startsWith("http") ? msg.media : `${API_BASE}${msg.media}`;
    content += `<img src="${src}" class="msg-media" onclick="window.open('${src}')" loading="lazy" />`;
  } else if (msg.media?.match(/\.(mp4|webm|mov)$/i)) {
    const src = msg.media.startsWith("http") ? msg.media : `${API_BASE}${msg.media}`;
    content += `<video src="${src}" class="msg-media-video" controls preload="metadata"></video>`;
  } else if (msg.media) {
    const src  = msg.media.startsWith("http") ? msg.media : `${API_BASE}${msg.media}`;
    const name = src.split("/").pop();
    content += `
      <div class="msg-doc" onclick="window.open('${src}')">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="none"
          stroke="currentColor" stroke-width="2">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
        </svg>
        <span class="msg-doc-name">${esc(name)}</span>
      </div>
    `;
  }

  if (msg.text && msg.type !== "gift") {
    content += `<div class="msg-text">${esc(msg.text)}</div>`;
  }

  content += `
    <div class="msg-meta">
      <span class="msg-time">${fmtTime(msg.createdAt)}</span>
      ${isSent ? `<span class="msg-ticks">✓</span>` : ""}
    </div>
  `;

  const col = document.createElement("div");
  col.className = "msg-col";

  // Sender name for received messages
  if (!isSent) {
    const nameDiv = document.createElement("div");
    nameDiv.className = "msg-sender-name";
    nameDiv.textContent = sender.fullName || sender.username || "";
    col.appendChild(nameDiv);
  }

  // Avatar for received
  if (!isSent) {
    const av = document.createElement("img");
    av.className = "row-avatar";
    av.src = sender.profilePicture || "/uploads/images/africa.png";
    av.onerror = () => { av.src = "/uploads/images/africa.png"; };
    row.appendChild(av);
  }

  const bubble = document.createElement("div");
  bubble.className = "msg-bubble";
  bubble.innerHTML = content;
  if (isSent) bubble.style.background = bubbleColor;

  col.appendChild(bubble);
  row.appendChild(col);

  // Long press / right click
  let pressTimer;
  row.addEventListener("touchstart", () => {
    pressTimer = setTimeout(() => openMsgMenu(msg), 600);
  }, { passive: true });
  row.addEventListener("touchend",  () => clearTimeout(pressTimer));
  row.addEventListener("touchmove", () => clearTimeout(pressTimer));
  row.addEventListener("contextmenu", e => { e.preventDefault(); openMsgMenu(msg); });

  msgList.appendChild(row);
}

window.playVoice = function(src, btn) {
  const audio = new Audio(src);
  audio.play();
  btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>`;
  audio.onended = () => {
    btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
  };
};

// ══════════════════════════════════════════════
//  SEND MESSAGE
// ══════════════════════════════════════════════
async function sendMessage() {
  const text = msgInput.value.trim();
  if (!text) return;
  msgInput.value = "";
  sendBtn.disabled = true;

  const tempId = `temp_${Date.now()}`;
  appendMsg({
    _id: tempId, sender: currentUserId,
    text, createdAt: new Date().toISOString(),
    replyTo: replyingTo
  }, true);
  scrollBottom(true);
  if (replyingTo) clearReply();

  try {
    const body = { text };
    if (replyingTo) body.replyTo = replyingTo._id;

    const newMsg = await api(`/api/messages/groups/${groupId}`, {
      method: "POST", body: JSON.stringify(body)
    });
    const tempEl = document.querySelector(`[data-msg-id="${tempId}"]`);
    if (tempEl) tempEl.dataset.msgId = newMsg._id;
  } catch(e) {
    showToast("Failed to send message");
    document.querySelector(`[data-msg-id="${tempId}"]`)?.remove();
  }

  sendBtn.disabled = false;
  msgInput.focus();
}

// ══════════════════════════════════════════════
//  SEND FILE
// ══════════════════════════════════════════════
async function sendFile(file) {
  const fd = new FormData();
  fd.append("media", file);
  if (replyingTo) { fd.append("replyTo", replyingTo._id); clearReply(); }
  showToast("Sending...");
  try {
    const res = await fetch(`${API_BASE}/api/messages/groups/${groupId}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: fd
    });
    if (!res.ok) throw new Error();
    const msg = await res.json();
    appendMsg(msg, true);
    scrollBottom(true);
  } catch(e) { showToast("Failed to send file"); }
}

// ══════════════════════════════════════════════
//  VOICE MESSAGE
// ══════════════════════════════════════════════
document.getElementById("voiceBtn").addEventListener("click", async () => {
  if (mediaRecorder?.state === "recording") return;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    voiceChunks = []; voiceSecs = 0;

    mediaRecorder.ondataavailable = e => voiceChunks.push(e.data);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(voiceChunks, { type:"audio/webm" });
      stream.getTracks().forEach(t => t.stop());
      voiceBar.style.display  = "none";
      inputArea.style.display = "block";
      clearInterval(voiceInterval);
      await sendFile(new File([blob], "voice.webm", { type:"audio/webm" }));
    };

    mediaRecorder.start();
    inputArea.style.display = "none";
    voiceBar.style.display  = "flex";

    voiceInterval = setInterval(() => {
      voiceSecs++;
      const m = Math.floor(voiceSecs/60), s = voiceSecs%60;
      document.getElementById("voiceTimer").textContent =
        `${m}:${s.toString().padStart(2,"0")}`;
    }, 1000);
  } catch(e) { showToast("Microphone access denied"); }
});

document.getElementById("voiceCancelBtn").addEventListener("click", () => {
  mediaRecorder?.stream?.getTracks().forEach(t => t.stop());
  mediaRecorder = null;
  clearInterval(voiceInterval);
  voiceBar.style.display  = "none";
  inputArea.style.display = "block";
});

document.getElementById("voiceSendBtn").addEventListener("click", () => {
  if (mediaRecorder?.state === "recording") mediaRecorder.stop();
});

// ══════════════════════════════════════════════
//  ATTACH OPTIONS
// ══════════════════════════════════════════════
document.getElementById("attachBtn").addEventListener("click", e => {
  e.stopPropagation();
  attachOpts.style.display =
    attachOpts.style.display === "none" ? "flex" : "none";
});

document.getElementById("attachImageBtn").addEventListener("click", () => {
  document.getElementById("fileInput").click();
  attachOpts.style.display = "none";
});

document.getElementById("attachGiftBtn").addEventListener("click", () => {
  attachOpts.style.display = "none";
  openGiftModal();
});

document.getElementById("attachDocBtn").addEventListener("click", () => {
  document.getElementById("docInput").click();
  attachOpts.style.display = "none";
});

document.getElementById("fileInput").addEventListener("change", () => {
  const f = document.getElementById("fileInput").files[0];
  if (f) { sendFile(f); document.getElementById("fileInput").value = ""; }
});

document.getElementById("docInput").addEventListener("change", () => {
  const f = document.getElementById("docInput").files[0];
  if (f) { sendFile(f); document.getElementById("docInput").value = ""; }
});

document.addEventListener("click", e => {
  if (!e.target.closest("#attachOptions") && !e.target.closest("#attachBtn"))
    attachOpts.style.display = "none";
});

// ══════════════════════════════════════════════
//  GIFT MODAL
// ══════════════════════════════════════════════
function openGiftModal() {
  giftSelected = null;
  buildGiftGrid();
  document.getElementById("giftStarBal").textContent = "...";
  document.getElementById("giftModal").style.display = "flex";
  loadGiftBalance();
}

function buildGiftGrid() {
  const grid = document.getElementById("giftGrid");
  grid.innerHTML = GIFTS.map((g,i) => `
    <div class="gift-item" data-idx="${i}">
      <span class="g-emoji">${g.emoji}</span>
      <span class="g-name">${g.name}</span>
      <span class="g-cost">⭐ ${g.stars.toLocaleString()}</span>
    </div>
  `).join("");
  grid.querySelectorAll(".gift-item").forEach(el => {
    el.addEventListener("click", () => {
      grid.querySelectorAll(".gift-item").forEach(x => x.classList.remove("selected"));
      el.classList.add("selected");
      giftSelected = GIFTS[parseInt(el.dataset.idx)];
      updateGiftBtn();
    });
  });
}

async function loadGiftBalance() {
  try {
    const d = await api("/api/wallet");
    giftBalance = d.starBalance || 0;
  } catch { giftBalance = 0; }
  document.getElementById("giftStarBal").textContent = giftBalance.toLocaleString();
  updateGiftBtn();
}

function updateGiftBtn() {
  const btn      = document.getElementById("giftSendBtn");
  const recharge = document.getElementById("giftRechargeBtn");
  if (!giftSelected) { btn.textContent = "Send Gift"; return; }
  if (giftSelected.stars > giftBalance) {
    btn.style.display      = "none";
    recharge.style.display = "inline-block";
  } else {
    btn.style.display      = "";
    recharge.style.display = "none";
    btn.textContent        = `Send ${giftSelected.emoji} Gift to Group`;
  }
}

document.getElementById("closeGiftModal").addEventListener("click", () => {
  document.getElementById("giftModal").style.display = "none";
});

document.getElementById("giftRechargeBtn").addEventListener("click", () => {
  window.location.href = "/wallet.html";
});

document.getElementById("giftSendBtn").addEventListener("click", async () => {
  if (!giftSelected) { showToast("Pick a gift first!"); return; }
  if (giftSelected.stars > giftBalance) { showToast("Not enough stars."); return; }

  const btn = document.getElementById("giftSendBtn");
  btn.disabled = true; btn.textContent = "Sending...";

  try {
    const res = await api("/api/wallet/gift/message", {
      method: "POST",
      body: JSON.stringify({
        groupId,
        giftType:  giftSelected.name,
        giftEmoji: giftSelected.emoji,
        amount:    giftSelected.stars
      })
    });

    document.getElementById("giftModal").style.display = "none";
    showToast(`🎁 ${giftSelected.emoji} Gift sent to group!`);

    appendMsg({
      _id:       res._id || Date.now().toString(),
      sender:    currentUserId,
      type:      "gift",
      giftType:  giftSelected.name,
      giftStars: giftSelected.stars,
      createdAt: new Date().toISOString()
    }, true);
    scrollBottom(true);
  } catch(e) { showToast(e.message || "Failed to send gift"); }

  btn.disabled = false;
  if (giftSelected) btn.textContent = `Send ${giftSelected.emoji} Gift to Group`;
});

// ══════════════════════════════════════════════
//  REPLY
// ══════════════════════════════════════════════
function setReply(msg) {
  replyingTo = msg;
  replyBar.style.display = "flex";
  document.getElementById("replyBarText").textContent = msg.text || "Media";
  msgInput.focus();
}

function clearReply() {
  replyingTo = null;
  replyBar.style.display = "none";
}

document.getElementById("replyBarClose").addEventListener("click", clearReply);

// ══════════════════════════════════════════════
//  MSG ACTION MENU
// ══════════════════════════════════════════════
function openMsgMenu(msg) {
  selectedMsg = msg;
  document.getElementById("msgActionMenu").style.display = "flex";
}

document.getElementById("actionReply").addEventListener("click", () => {
  if (selectedMsg) setReply(selectedMsg);
  document.getElementById("msgActionMenu").style.display = "none";
});

document.getElementById("actionForward").addEventListener("click", () => {
  document.getElementById("msgActionMenu").style.display = "none";
  showToast("Open a chat to forward this message");
});

document.getElementById("actionDelete").addEventListener("click", () => {
  document.getElementById("msgActionMenu").style.display = "none";
  document.getElementById("deleteMsgModal").style.display = "flex";
});

document.getElementById("actionCancel").addEventListener("click", () => {
  document.getElementById("msgActionMenu").style.display = "none";
});

// ══════════════════════════════════════════════
//  DELETE MESSAGE
// ══════════════════════════════════════════════
async function deleteMsg(forEveryone) {
  if (!selectedMsg) return;
  document.getElementById("deleteMsgModal").style.display = "none";
  try {
    await api(`/api/messages/${selectedMsg._id}`, {
      method: "DELETE",
      body: JSON.stringify({ forEveryone })
    });
    document.querySelector(`[data-msg-id="${selectedMsg._id}"]`)?.remove();
    showToast(forEveryone ? "Deleted for everyone" : "Deleted for you");
  } catch(e) { showToast("Failed to delete"); }
  selectedMsg = null;
}

document.getElementById("deleteForMe").addEventListener("click",       () => deleteMsg(false));
document.getElementById("deleteForEveryone").addEventListener("click", () => deleteMsg(true));
document.getElementById("cancelDelete").addEventListener("click", () => {
  document.getElementById("deleteMsgModal").style.display = "none";
  selectedMsg = null;
});

// ══════════════════════════════════════════════
//  THREAD MENU
// ══════════════════════════════════════════════
document.getElementById("chatMenuBtn").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "flex";
});

document.getElementById("groupInfoBtn").addEventListener("click", openGroupInfo);

document.getElementById("menuGroupInfo").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "none";
  openGroupInfo();
});

document.getElementById("menuChatSettings").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "none";
  openChatSettings();
});

document.getElementById("menuInviteLink").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "none";
  const link = `${window.location.origin}/join-group.html?groupId=${groupId}`;
  navigator.clipboard.writeText(
    `Join me on Afrisocial, let's chat! ${link}`
  ).then(() => showToast("Invite link copied!"))
   .catch(() => showToast(link));
});

document.getElementById("menuClearChat").addEventListener("click", async () => {
  document.getElementById("threadMenu").style.display = "none";
  if (!confirm("Clear all messages in this group?")) return;
  try {
    await api(`/api/messages/groups/${groupId}/clear`, { method: "DELETE" });
    msgList.innerHTML = `<div style="text-align:center;padding:40px;color:#9CA3AF;">Chat cleared</div>`;
    showToast("Chat cleared");
  } catch(e) { showToast("Failed to clear"); }
});

document.getElementById("menuReportGroup").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "none";
  showToast("Group reported. Thank you!");
});

document.getElementById("menuLeaveGroup").addEventListener("click", async () => {
  document.getElementById("threadMenu").style.display = "none";
  if (!confirm("Leave this group?")) return;
  try {
    await api(`/api/messages/groups/${groupId}/leave`, { method: "POST" });
    showToast("You left the group");
    setTimeout(() => history.back(), 800);
  } catch(e) { showToast("Failed to leave group"); }
});

document.getElementById("menuCancel").addEventListener("click", () => {
  document.getElementById("threadMenu").style.display = "none";
});

// ══════════════════════════════════════════════
//  GROUP INFO PANEL
// ══════════════════════════════════════════════
function openGroupInfo() {
  const panel = document.getElementById("groupInfoPanel");
  panel.style.display = "block";

  const group = groupData || {};
  const initials = (group.name || groupName).substring(0,2).toUpperCase();

  // Avatar
  const avEl = document.getElementById("groupInfoAvatar");
  if (group.profilePicture) {
    avEl.innerHTML = `<img src="${group.profilePicture}"
      onerror="this.parentElement.textContent='${initials}'" />`;
  } else {
    avEl.textContent = initials;
  }

  document.getElementById("groupInfoName").textContent  = group.name || groupName;
  document.getElementById("groupInfoDesc").textContent  = group.description || "";
  document.getElementById("groupInfoCount").textContent = `${members.length} members`;

  // Admin-only controls
  if (isAdmin) {
    document.getElementById("editGroupBtn").style.display        = "flex";
    document.getElementById("adminInviteWrap").style.display     = "block";
    document.getElementById("changeGroupPhotoBtn").style.display = "block";
    document.getElementById("deleteGroupBtn").style.display      = "block";
  }

  renderMembersList();
}

function renderMembersList() {
  const list = document.getElementById("membersList");
  list.innerHTML = members.map(m => `
    <div class="member-item">
      <img class="member-avatar"
        src="${m.profilePicture || '/uploads/images/africa.png'}"
        onerror="this.src='/uploads/images/africa.png'" />
      <div class="member-info">
        <div class="member-name">${esc(m.fullName || m.username)}</div>
        <div class="member-handle">@${m.username || ""}</div>
      </div>
      ${m.role === "admin" ? `<span class="member-role">Admin</span>` : ""}
      ${isAdmin && m._id !== currentUserId
        ? `<button class="member-remove-btn" data-uid="${m._id}"
             data-name="${esc(m.fullName||m.username)}">Remove</button>`
        : ""}
    </div>
  `).join("");

  list.querySelectorAll(".member-remove-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      memberToRemove = { id: btn.dataset.uid, name: btn.dataset.name };
      document.getElementById("removeMemberName").textContent =
        `Remove ${memberToRemove.name} from this group?`;
      document.getElementById("removeMemberModal").style.display = "flex";
    });
  });
}

document.getElementById("closeGroupInfo").addEventListener("click", () => {
  document.getElementById("groupInfoPanel").style.display = "none";
});

// Edit group
document.getElementById("editGroupBtn").addEventListener("click", () => {
  const form = document.getElementById("groupEditForm");
  const isOpen = form.style.display !== "none";
  form.style.display = isOpen ? "none" : "block";
  if (!isOpen) {
    document.getElementById("editGroupName").value = groupData?.name || "";
    document.getElementById("editGroupDesc").value = groupData?.description || "";
  }
});

document.getElementById("saveGroupEditBtn").addEventListener("click", async () => {
  const name = document.getElementById("editGroupName").value.trim();
  const desc = document.getElementById("editGroupDesc").value.trim();
  if (!name) { showToast("Group name is required"); return; }

  const btn = document.getElementById("saveGroupEditBtn");
  btn.disabled = true; btn.textContent = "Saving...";

  try {
    const updated = await api(`/api/messages/groups/${groupId}`, {
      method: "PATCH",
      body: JSON.stringify({ name, description: desc })
    });
    groupData = { ...groupData, name, description: desc };
    document.getElementById("groupInfoName").textContent = name;
    document.getElementById("groupInfoDesc").textContent = desc;
    renderHeader(groupData);
    document.getElementById("groupEditForm").style.display = "none";
    showToast("Group updated!");
  } catch(e) { showToast("Failed to update group"); }

  btn.disabled = false; btn.textContent = "Save Changes";
});

// Change group photo
document.getElementById("changeGroupPhotoBtn").addEventListener("click", () => {
  document.getElementById("groupPhotoInput").click();
});

document.getElementById("groupPhotoInput").addEventListener("change", async () => {
  const f = document.getElementById("groupPhotoInput").files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append("photo", f);
  try {
    const res = await fetch(`${API_BASE}/api/messages/groups/${groupId}/photo`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: fd
    });
    if (!res.ok) throw new Error();
    const data = await res.json();
    groupData.profilePicture = data.profilePicture;
    const avEl = document.getElementById("groupInfoAvatar");
    avEl.innerHTML = `<img src="${data.profilePicture}" />`;
    renderHeader(groupData);
    showToast("Group photo updated!");
  } catch(e) { showToast("Failed to update photo"); }
});

// Invite member
document.getElementById("inviteMemberBtn").addEventListener("click", () => {
  document.getElementById("inviteModal").style.display = "flex";
  document.getElementById("inviteSearchInput").value   = "";
  document.getElementById("inviteSearchResults").innerHTML = "";
});

document.getElementById("closeInviteModal").addEventListener("click", () => {
  document.getElementById("inviteModal").style.display = "none";
});

document.getElementById("inviteSearchInput").addEventListener("input", async e => {
  const q = e.target.value.trim();
  if (!q) { document.getElementById("inviteSearchResults").innerHTML = ""; return; }
  try {
    const data  = await api(`/api/users/search?q=${encodeURIComponent(q)}`);
    const users = (data.users || []).filter(u =>
      !members.find(m => m._id === u._id)
    );
    const res = document.getElementById("inviteSearchResults");
    if (!users.length) { res.innerHTML = '<p style="color:#9CA3AF;padding:12px;">No users found</p>'; return; }
    res.innerHTML = users.map(u => `
      <div class="invite-result-item">
        <img src="${u.profilePicture || '/uploads/images/africa.png'}"
             onerror="this.src='/uploads/images/africa.png'" />
        <div class="invite-result-info">
          <strong>${esc(u.fullName || u.username)}</strong>
          <span>@${u.username}</span>
        </div>
        <button class="add-btn" data-uid="${u._id}">Add</button>
      </div>
    `).join("");

    res.querySelectorAll(".add-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        btn.disabled = true; btn.textContent = "Adding...";
        try {
          await api(`/api/messages/groups/${groupId}/members`, {
            method: "POST",
            body: JSON.stringify({ userId: btn.dataset.uid })
          });
          showToast("Member added!");
          btn.textContent = "Added ✓";
          await loadGroupInfo();
          renderMembersList();
        } catch(e) {
          showToast("Failed to add member");
          btn.disabled = false; btn.textContent = "Add";
        }
      });
    });
  } catch(e) {}
});

// Remove member
document.getElementById("confirmRemoveMember").addEventListener("click", async () => {
  if (!memberToRemove) return;
  document.getElementById("removeMemberModal").style.display = "none";
  try {
    await api(`/api/messages/groups/${groupId}/members/${memberToRemove.id}`, {
      method: "DELETE"
    });
    members = members.filter(m => m._id !== memberToRemove.id);
    renderMembersList();
    document.getElementById("groupInfoCount").textContent = `${members.length} members`;
    showToast(`${memberToRemove.name} removed`);
  } catch(e) { showToast("Failed to remove member"); }
  memberToRemove = null;
});

document.getElementById("cancelRemoveMember").addEventListener("click", () => {
  document.getElementById("removeMemberModal").style.display = "none";
  memberToRemove = null;
});

// Leave group
document.getElementById("leaveGroupBtn").addEventListener("click", async () => {
  if (!confirm("Leave this group?")) return;
  try {
    await api(`/api/messages/groups/${groupId}/leave`, { method: "POST" });
    showToast("You left the group");
    setTimeout(() => history.back(), 800);
  } catch(e) { showToast("Failed to leave group"); }
});

// Delete group (admin)
document.getElementById("deleteGroupBtn").addEventListener("click", async () => {
  if (!confirm("Delete this group permanently? This cannot be undone.")) return;
  try {
    await api(`/api/messages/groups/${groupId}`, { method: "DELETE" });
    showToast("Group deleted");
    setTimeout(() => history.back(), 800);
  } catch(e) { showToast("Failed to delete group"); }
});

// ══════════════════════════════════════════════
//  CHAT SETTINGS
// ══════════════════════════════════════════════
const BG_OPTIONS = [
  { label:"None",    value:"",         color:"#F9FAFB" },
  { label:"Dark",    value:"#0D0F1A",  color:"#0D0F1A" },
  { label:"Forest",  value:"https://images.unsplash.com/photo-1448375240586-882707db888b?w=400" },
  { label:"Ocean",   value:"https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=400" },
  { label:"Sunset",  value:"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400" },
  { label:"Stars",   value:"https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400" },
  { label:"Africa",  value:"https://images.unsplash.com/photo-1489392191049-fc10c97e64b6?w=400" },
  { label:"Kente",   value:"https://images.unsplash.com/photo-1611348524140-53c9a25263d6?w=400" },
  { label:"Abstract",value:"https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400" },
];

function openChatSettings() {
  buildBgGrid();
  document.querySelectorAll(".color-dot").forEach(d => {
    d.classList.toggle("active", d.dataset.color === bubbleColor);
  });
  document.getElementById("chatSettingsModal").style.display = "block";
}

function buildBgGrid() {
  const grid = document.getElementById("bgGrid");
  grid.innerHTML = BG_OPTIONS.map(bg => {
    const isUrl    = bg.value?.startsWith("http");
    const isActive = chatBg === bg.value;
    if (isUrl) {
      return `<div class="bg-opt ${isActive?"active":""}" data-bg="${bg.value}">
        <img src="${bg.value}" loading="lazy" />
      </div>`;
    }
    return `<div class="bg-opt solid ${isActive?"active":""}" data-bg="${bg.value}"
      style="background:${bg.color||"#F9FAFB"};">${bg.label}</div>`;
  }).join("");

  grid.querySelectorAll(".bg-opt").forEach(el => {
    el.addEventListener("click", () => {
      grid.querySelectorAll(".bg-opt").forEach(x => x.classList.remove("active"));
      el.classList.add("active");
      chatBg = el.dataset.bg;
      localStorage.setItem(`groupBg_${groupId}`, chatBg);
      applyBg(chatBg);
    });
  });
}

function applyBg(bg) {
  if (!bg) {
    chatMessages.style.backgroundImage = "";
    chatMessages.style.backgroundColor = "";
    chatMessages.classList.remove("has-bg");
  } else if (bg.startsWith("http")) {
    chatMessages.style.backgroundImage = `url(${bg})`;
    chatMessages.style.backgroundColor = "";
    chatMessages.classList.add("has-bg");
  } else {
    chatMessages.style.backgroundImage = "";
    chatMessages.style.backgroundColor = bg;
    chatMessages.classList.add("has-bg");
  }
}

function applyBubbleColor(color) {
  bubbleColor = color;
  document.querySelectorAll(".msg-row.sent .msg-bubble").forEach(el => {
    el.style.background = color;
  });
}

document.querySelectorAll(".color-dot").forEach(dot => {
  dot.addEventListener("click", () => {
    document.querySelectorAll(".color-dot").forEach(d => d.classList.remove("active"));
    dot.classList.add("active");
    bubbleColor = dot.dataset.color;
    localStorage.setItem("bubbleColor", bubbleColor);
    applyBubbleColor(bubbleColor);
  });
});

document.getElementById("closeSettingsBtn").addEventListener("click", () => {
  document.getElementById("chatSettingsModal").style.display = "none";
});

// ══════════════════════════════════════════════
//  INPUT EVENTS
// ══════════════════════════════════════════════
sendBtn.addEventListener("click", sendMessage);

msgInput.addEventListener("keypress", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

// ══════════════════════════════════════════════
//  BACK
// ══════════════════════════════════════════════
document.getElementById("chatBackBtn").addEventListener("click", () => {
  if (history.length > 1) history.back();
  else window.location.href = "/message.html";
});

// ══════════════════════════════════════════════
//  POLLING
// ══════════════════════════════════════════════
function startPolling() {
  stopPolling();
  polling = setInterval(() => loadMessages(false), 4000);
}
function stopPolling() { clearInterval(polling); polling = null; }

chatMessages.addEventListener("scroll", () => {
  if (chatMessages.scrollTop === 0 && hasMore && !loadingMsgs) {
    msgPage++;
    loadMessages(false);
  }
});

// ══════════════════════════════════════════════
//  CLOSE OVERLAYS
// ══════════════════════════════════════════════
["threadMenu","msgActionMenu","giftModal","inviteModal"].forEach(id => {
  document.getElementById(id)?.addEventListener("click", e => {
    if (e.target === document.getElementById(id))
      document.getElementById(id).style.display = "none";
  });
});

// ══════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════
async function init() {
  applyBg(chatBg);
  applyBubbleColor(bubbleColor);
  await loadGroupInfo();
  await loadMessages(true);
  startPolling();
}

init();
