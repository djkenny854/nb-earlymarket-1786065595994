/**
 * mention.js
 * Drop-in frontend controller for handling live user database mentions.
 */

function initMentionAutocomplete(selector) {
    const textInputs = document.querySelectorAll(selector);

    textInputs.forEach(input => {
        let dropdown = null;
        let activeIndex = -1;
        let atSymbolIndex = -1;
        let debounceTimer = null;

        // Input/Typing tracking
        input.addEventListener("input", () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(async () => {
                const textVal = input.value;
                const cursorPosition = input.selectionStart;

                // Track backwards to find the nearest '@' symbol
                const lastAtIdx = textVal.lastIndexOf("@", cursorPosition - 1);

                if (lastAtIdx !== -1) {
                    const prevChar = textVal.charAt(lastAtIdx - 1);
                    const isWordStart = lastAtIdx === 0 || /\s/.test(prevChar);

                    if (isWordStart) {
                        const potentialQuery = textVal.substring(lastAtIdx + 1, cursorPosition);

                        // If user typed a space, dismiss autocomplete
                        if (!/\s/.test(potentialQuery)) {
                            atSymbolIndex = lastAtIdx;

                            const matches = await fetchMatchingUsers(potentialQuery);
                            if (matches && matches.length > 0) {
                                // Create dropdown element if it doesn't exist yet
                                if (!dropdown) {
                                    dropdown = document.createElement("div");
                                    dropdown.className = "mention-dropdown";
                                    input.parentNode.appendChild(dropdown);
                                }
                                
                                activeIndex = renderDropdown(dropdown, input, matches, atSymbolIndex, () => {
                                    dropdown = null;
                                });
                            } else {
                                removeDropdown();
                            }
                            return;
                        }
                    }
                }
                removeDropdown();
            }, 150);
        });

        // Keyboard Navigation (Up, Down, Enter, Escape)
        input.addEventListener("keydown", (e) => {
            if (!dropdown || dropdown.style.display !== "block") return;

            const items = dropdown.querySelectorAll(".mention-item");
            if (items.length === 0) return;

            if (e.key === "ArrowDown") {
                e.preventDefault();
                activeIndex = (activeIndex + 1) % items.length;
                highlightItem(items, activeIndex);
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                activeIndex = (activeIndex - 1 + items.length) % items.length;
                highlightItem(items, activeIndex);
            } else if (e.key === "Enter") {
                e.preventDefault();
                if (activeIndex > -1 && items[activeIndex]) {
                    items[activeIndex].click();
                }
            } else if (e.key === "Escape") {
                e.preventDefault();
                removeDropdown();
            }
        });

        // Dismiss when clicking anywhere outside
        document.addEventListener("click", (e) => {
            if (dropdown && !dropdown.contains(e.target) && e.target !== input) {
                removeDropdown();
            }
        });

        // Clean removal helper scoped to this input context
        function removeDropdown() {
            if (dropdown) {
                dropdown.style.display = "none";
            }
            activeIndex = -1;
        }
    });
}

/**
 * Global Helper Functions (Keeps memory footprint low)
 */

// Backend API fetcher with auth integration
async function fetchMatchingUsers(query) {
    try {
        const token = localStorage.getItem("token"); 

        const response = await fetch(`https://afrisocial-backend.onrender.com/api/users/search-mentions?query=${encodeURIComponent(query)}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            }
        });
        
        if (!response.ok) throw new Error("API call failed");
        return await response.json();
    } catch (err) {
        console.warn("Mention query error: ", err);
        return [];
    }
}

// Spawns and structures the popup list items
function renderDropdown(dropdown, targetInput, users, atSymbolIndex, onDestroy) {
    dropdown.innerHTML = "";

    // Verified badge SVG icon template
    const verifiedBadgeIcon = `
        <span class="mention-verified-badge" title="Verified User">
            <svg viewBox="0 0 24 24" aria-label="Verified account">
                <path d="M22.25 12c0-1.43-.88-2.67-2.19-3.19.46-1.39.02-2.96-1.08-3.99-1.03-1.1-2.6-1.54-3.99-1.08C14.47 2.43 13.23 1.55 11.8 1.55c-1.43 0-2.67.88-3.19 2.19-1.39-.46-2.96-.02-3.99 1.08-1.1 1.03-1.54 2.6-1.08 3.99C2.43 9.33 1.55 10.57 1.55 12c0 1.43.88 2.67 2.19 3.19-.46 1.39-.02 2.96 1.08 3.99 1.03 1.1 2.6 1.54 3.99 1.08.52 1.31 1.76 2.19 3.19 2.19 1.43 0 2.67-.88 3.19-2.19 1.39.46 2.96.02 3.99-1.08 1.1-1.03 1.54-2.6 1.08-3.99 1.31-.52 2.19-1.76 2.19-3.19zm-11.71 4.2L6.3 11.96l1.41-1.41 2.83 2.83 6.88-6.88 1.41 1.41-8.29 8.29z"/>
            </svg>
        </span>
    `;

    users.forEach((user, idx) => {
        const item = document.createElement("div");
        item.className = "mention-item";
        item.dataset.index = idx;

        const avatarUrl = user.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.username)}&background=random&color=fff`;

        // Check for verified status in backend schema
        const badgeHtml = user.isVerified ? verifiedBadgeIcon : "";

        item.innerHTML = `
            <img src="${avatarUrl}" class="mention-avatar" alt="${user.username}" />
            <div class="mention-details">
                <div class="mention-user-header">
                    <span class="mention-username">@${user.username}</span>
                    ${badgeHtml}
                </div>
                <span class="mention-fullname">${user.fullName || ""}</span>
            </div>
        `;

        item.addEventListener("click", () => {
            commitMentionSelection(targetInput, user.username, atSymbolIndex);
            if (dropdown) dropdown.style.display = "none";
        });

        dropdown.appendChild(item);
    });

    // --- Dynamic Smart Positioning Block ---
    dropdown.style.left = "0px";
    
    // Check if target input is in post composer or comments
    if (targetInput.id === "postInput" || targetInput.classList.contains("mention-input-target")) {
        dropdown.classList.remove("drop-up");
        dropdown.classList.add("drop-down");
        dropdown.style.top = `${targetInput.offsetTop + targetInput.offsetHeight}px`;
        dropdown.style.bottom = "auto";
    } else {
        dropdown.classList.remove("drop-down");
        dropdown.classList.add("drop-up");
        dropdown.style.bottom = `${targetInput.offsetHeight}px`;
        dropdown.style.top = "auto"; 
    }
    
    dropdown.style.display = "block";
    return -1; // Resets the active index counter mapping
}

// Manages keyboard active tracking classes
function highlightItem(items, activeIndex) {
    items.forEach((item, index) => {
        if (index === activeIndex) {
            item.classList.add("selected");
            item.scrollIntoView({ block: "nearest" });
        } else {
            item.classList.remove("selected");
        }
    });
}

// Handles string parsing and moving typing cursor focus naturally
function commitMentionSelection(targetInput, username, atSymbolIndex) {
    const currentVal = targetInput.value;
    const beforeMention = currentVal.substring(0, atSymbolIndex);
    const afterMention = currentVal.substring(targetInput.selectionStart);

    targetInput.value = `${beforeMention}@${username} ${afterMention}`;
    targetInput.focus();

    const targetCursorPosition = beforeMention.length + username.length + 2; 
    targetInput.setSelectionRange(targetCursorPosition, targetCursorPosition);
}
