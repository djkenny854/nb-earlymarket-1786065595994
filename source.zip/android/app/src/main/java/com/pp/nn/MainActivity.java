package com.pp.nn;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
